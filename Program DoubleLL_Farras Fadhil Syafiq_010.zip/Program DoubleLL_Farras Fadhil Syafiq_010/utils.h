#ifndef UTILS_H
#define UTILS_H 

void inputString(char **s);

#endif
